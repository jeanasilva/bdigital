$(document).ready(function() {
    $("#telefone").mask("(00)00000-0000");
});

function myFunction(x) {
    x.value = "(92)";
}

new Vue({
    el: '#app',
    data() {
        return {
            errors: [],
            cpf: '',
            nome: '',
            telefone: '',
            email: '',
            message: 'B Digital Mais',
            Usuarios: [],
            msg: [],
            // loadCep: {
            //     cep: '',
            //     bairro: '',
            //     logradouro: '',
            //     localidade: '',
            //     uf: '',
            //     data: '',
            //     messageCep: ''
            // },
            novoUsuario: {
                cpf: '',
                nome: '',
                telefone: '',
                email: '',
                cep: '',
                bairro: '',
                logradouro: '',
                localidade: '',
                uf: ''
            },

        }
    },

    watch: {
        'novoUsuario.email' (value) {
            this.email = value;
            this.validateEmail(value);
        },

        'novoUsuario.telefone' (value) {
            this.telefone = value;
            this.validateFone(value);
        }
    },

    methods: {
        inserirUsuarios() {

            nErros = 0;
            this.errors = [];

            if (!this.validateEmail(this.email)) {
                this.msg['email'] = 'Utilize um e-mail válido.';
                nErros++;
            }

            if (!this.validateFone(this.telefone)) {

                this.msg['fone'] = 'Utilize um número de telefone válido.';
                nErros++;
            }


            if (nErros > 0) {

                $('#checkform').submit(function(evt) {
                    evt.preventDefault();
                });

            } else {

                axios.post('http://127.0.0.1:8000/api/usuarios', this.novoUsuario)
                    .then(res => {
                        this.novoUsuario.cpf = ''
                        this.novoUsuario.nome = ''
                        this.novoUsuario.telefone = ''
                        this.novoUsuario.email = ''
                        this.novoUsuario.cep = ''
                        this.novoUsuario.bairro = ''
                        this.novoUsuario.logradouro = ''
                        this.novoUsuario.localidade = ''
                        this.novoUsuario.uf = ''

                        alert('Você será redirecionado para a pagina principal da Bemol!!')
                        window.location.href = '/chatbdigital';
                    })
            }

        },

        carregarCep() {
            if (this.novoUsuario.cep.length == 8) {
                axios.get(`https://cors-anywhere.herokuapp.com/https://viacep.com.br/ws/${this.novoUsuario.cep }/json/`, {
                        headers: {
                            "Access-Control-Allow-Origin": "*",
                            "Access-Control-Allow-Headers": "Authorization",
                            "Access-Control-Allow-Methods": "GET, POST, OPTIONS, PUT, PATCH, DELETE",
                            "Content-Type": "application/json;charset=UTF-8"
                        },
                    })
                    .then(res => console.log(this.novoUsuario = res.data)); {}
            }

        },

        validarCpf() {
            if (this.novoUsuario.cpf = novoUsuario.cpf) {
                axios.get('http://127.0.0.1:8000/api/usuarios')
            }
        },

        checkForm: function(e) {

            nErros = 0;
            this.errors = [];

            if (!this.validateEmail(this.email)) {
                this.msg['email'] = 'Utilize um e-mail válido.';
                nErros++;
            }

            if (!this.validateFone(this.telefone)) {

                this.msg['fone'] = 'Utilize um número de telefone válido.';
                nErros++;
            }


            if (nErros > 0) {

                e.preventDefault();
            } else {

                this.inserirUsuarios();
            }

        },

        validateEmail(value) {
            if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value)) {
                this.msg['email'] = '';
                return true;
            } else {
                this.msg['email'] = 'Utilize um e-mail válido.';
                return false;
            }
        },
        validateFone(value) {

            if (
                (!(/^(\d)[0-9]\1{5,12}$/.test(value))) &&
                (/^(?:\(?([1-9][0-9])\)?\s?)?(?:((?:9\d|[2-9])\d{3})\-?(\d{4}))$/.test(value))) {
                this.msg['fone'] = '';
                return true;
            } else {
                this.msg['fone'] = 'Utilize um número de telefone válido.';
                return false;
            }
        }
    }
})